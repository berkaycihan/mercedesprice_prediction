import scrapy

class MercedesCSpider(scrapy.Spider):
    name = 'mercedes_c'
    allowed_domains = ['araba.com', 'www.araba.com']
    start_urls = ['https://www.araba.com/otomobil/mercedes-c']

    def parse(self, response):
        arabalar = response.xpath("//table[@class='list-table']/tbody/tr/td[@class='offer-title-column']")
        for araba in arabalar:
            if response.xpath("//div[@class='photo-container']/div[@class='sold-badge']").get():
                continue

            araba_linki = response.urljoin(araba.xpath("./a[contains(@class, 'title')]/@href").get())
            # yield {
            #     'link' : araba_linki
            # }
            yield scrapy.Request(araba_linki, callback=self.arac_detay)

        sonraki_sayfa = response.urljoin(response.xpath("(//a[@class='btn next']/@href)[2]").get())
        if sonraki_sayfa:
            yield scrapy.Request(url=sonraki_sayfa, callback=self.parse)

    def arac_detay(self, response):
        bilgi_alani = response.xpath("//div[@class='car-detail-container']")
        yield {
            'baslik'        : response.xpath("normalize-space(//h1[@class='offer-detail-title']/text())").get(),
            'fiyat'         : bilgi_alani.xpath("normalize-space(.//span[@class='offer-price']/text())").get(),
            'adres'         : response.xpath("normalize-space(//div[@class='offer-district-container'])").get(),
            'ilan_no'       : bilgi_alani.xpath("normalize-space(.//span[text()='İlan No:']/following-sibling::span/text())").get(),
            'ilan_tarihi'   : bilgi_alani.xpath("normalize-space(.//span[text()='İlan Tarihi:']/following-sibling::span/text())").get(),
            'marka'         : bilgi_alani.xpath("normalize-space(.//span[text()='Marka:']/following-sibling::span/text())").get(),
            'model'         : bilgi_alani.xpath("normalize-space(.//span[text()='Model:']/following-sibling::span/text())").get(),
            'varyant'       : bilgi_alani.xpath("normalize-space(.//span[text()='Varyant:']/following-sibling::span/text())").get(),
            'model_yili'    : bilgi_alani.xpath("normalize-space(.//span[text()='Model Yılı:']/following-sibling::span/text())").get(),
            'kilometre'     : bilgi_alani.xpath("normalize-space(.//span[text()='Kilometre:']/following-sibling::span/text())").get(),
            'yakit_turu'    : bilgi_alani.xpath("normalize-space(.//span[text()='Yakıt Türü:']/following-sibling::span/text())").get(),
            'vites_tipi'    : bilgi_alani.xpath("normalize-space(.//span[text()='Vites Tipi:']/following-sibling::span/text())").get(),
            'motor_hacmi'   : bilgi_alani.xpath("normalize-space(.//span[text()='Motor Hacmi:']/following-sibling::span/text())").get(),
            'motor_gucu'    : bilgi_alani.xpath("normalize-space(.//span[text()='Motor Gücü:']/following-sibling::span/text())").get(),
            'kimden'        : bilgi_alani.xpath("normalize-space(.//span[text()='Kimden:']/following-sibling::span/text())").get()
        }