from json import load

a_seri = load(open('mercedes_a_seri.json',  'r', encoding='utf-8'))
b_seri = load(open('mercedes_b_seri.json',  'r', encoding='utf-8'))
c_seri = load(open('mercedes_c.json',       'r', encoding='utf-8'))
e_seri = load(open('mercedes_e_seri.json',  'r', encoding='utf-8'))

print(f"""23 Mart 2032 02:00 Satıştaki Araçlar;

A-Seri » {len(a_seri)} Adet
B-Seri » {len(b_seri)} Adet
C-Seri » {len(c_seri)} Adet
E-Seri » {len(e_seri)} Adet

Toplam » {len(a_seri) + len(b_seri) + len(c_seri) + len(e_seri)} Adet
""")